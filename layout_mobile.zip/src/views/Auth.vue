<script setup lang="ts">
import { onBeforeMount, ref } from 'vue';
import { useRouter } from 'vue-router';
import { useStore } from 'vuex';
import axios from 'axios';

const login = ref({
    email: 'super_admin@your.app',
    password: 'baseapps',
    remember: false
});

const router = useRouter();
const store = useStore();

onBeforeMount(async () => {
    try {
        if (!store.state.user.user.email) {
            var auth = await axios.get('/api/user');
            store.commit('storeUser', auth.data);
            setTimeout(() => {
                if (store.state.user.user.email) {
                    router.push('/pagina/index');
                } else {
                    router.push('/pagina/login');
                }
            }, 800);
        } else {
            setTimeout(() => {
                router.push('/pagina/index'),
                    500
            })
        }

    } catch (e) {
        console.log(e?.response?.data.message)
    }
});


const handleLogin = async () => {
    try {
        await axios.post('login', {
            email: login.value.email,
            password: login.value.password,
            remember: login.value.remember
        })
            .then(auth => {
                store.commit('storeUser', auth.data);
                setTimeout(() => {
                    router.push('/pagina/index'),
                        500
                })
            })

    } catch (error) {
        // console.log(error?.response?.data)
        console.log(error)
    }
}

</script>
<template>
    <input type="email" v-model="login.email" />
    <input type="password" v-model="login.password" />
    <input type="" v-model="login.remember" />Lembrar de mim.
    <button class="px-6" color="tertiary" @click="handleLogin">Entrar</button>
    <p>{{ $store.state.user.name }}</p>
    <p>$store.state.user.name</p>
    <p>{{ $store.state.user }}</p>
</template>