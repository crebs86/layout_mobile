export default {
    state: {
        user: {}
    },
    mutations: {
        storeUser(state, data) {
            state.user = data
        }
    },
    actions: {},
    getters: {}
}