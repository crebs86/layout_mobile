<template>
  <h1 class="text-center text-xl">Bem-vindos a Nutrix</h1>
  <p class="text-justify px-2 mt-3">
    Este APP é voltado para nutricionistas, mas seu uso não é limitado a estes. Recomendamos não utilizar nem tomar desições sem a
    supervisão/orientação profissional.
  </p>
  <p class="text-justify px-2 mt-3">
    <span class="font-bold">Calculadora Índice de Massa Corpórea (IMC):</span> cálculo simples do índice de massa
    corpórea.
  </p>
  <p class="text-justify px-2 mt-3">
    <span class="font-bold">Calculadora de Gasto Energético:</span> calcula a Estimativa de Necessidade Energética
    diária em Kcal, IMC e sua classificação.
  </p>
</template>
