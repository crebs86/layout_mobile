import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'dev.crebs.layout_mobile',
  appName: 'layout_mobile',
  webDir: 'dist'
};

export default config;
