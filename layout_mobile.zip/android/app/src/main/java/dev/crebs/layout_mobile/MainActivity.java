package dev.crebs.layout_mobile;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
